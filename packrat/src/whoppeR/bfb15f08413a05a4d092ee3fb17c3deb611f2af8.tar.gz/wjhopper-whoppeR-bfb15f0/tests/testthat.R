library(testthat)
library(whoppeR)

test_check("whoppeR")
